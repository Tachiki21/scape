#ifndef _USER_C_
#define _USER_C_

#define LOG32(n) (log(n) / log(3.0/2.0)) //macro declaration

typedef struct Node //Node declaration
{
    int data;
    int n, q;
    struct Node *left;
    struct Node *right;
    struct Node *parent;
} Node;

int size(Node *root);

int depth(Node *root);

Node *addNode(int data);

int search(Node *root, int data);

Node *sgSearch(Node *root, int data);

Node *insert(Node *root, int data);

Node *flatten(Node *x, Node *y);

Node *buildTree(int n, Node *x);

Node *rebuild(int n, Node *s);

Node *scapeInsert(Node *root, int data);

Node *minData(Node *root);

Node *delete(Node *root, int data);

void preOrder(Node *root);

void postOrder(Node *root);

void inOrder (Node *root);

void empty(Node *root);

#endif