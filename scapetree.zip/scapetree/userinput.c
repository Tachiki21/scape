#include <stdio.h>
#include <functions.h>

char trav;
int data;
char cmd;
Node* root;
int main()
{

    do {
            do {
                scanf("%c", &cmd);
            } while(isspace(cmd));
            
            switch (cmd)
            { 
                    
                case 'i': // push a value
                    // read value to push
                    scanf("%d", &data);
                    root = scapeInsert(root, data);
                    break;
                case 'd': 
                    scanf("%d",&data);
                    root = delete(root, data);
                    break;
                case 's': 
                    scanf("%d", &data);
                    break;
                case 'e':
                    empty(root);
                    break;
                case 't':
                    scanf("%c", &trav);
                    if(isspace(trav))
                    {
                        inOrder(root);  
                    }
                    {
                        scanf("%c", &trav);
                    }
                        if(trav == 'i');
                        {
                            inOrder(root);
                        }
                    break;
                case 'q':
                    break;
                    
                default:            
                    printf("Oi! That's not a legal command\n");
            }
            
        } while (cmd != 'q');
}